<?php
/**
 * Permissions Lexicon Entries for Babel
 *
 * @package babel
 * @subpackage lexicon
 */
$_lang['babel.permission.babel_settings_desc'] = 'To edit the Babel setting in the Babel custom manager page.';
