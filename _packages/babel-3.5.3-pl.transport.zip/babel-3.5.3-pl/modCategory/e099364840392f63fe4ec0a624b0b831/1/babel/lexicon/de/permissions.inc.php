<?php
/**
 * Permissions Lexicon Entries for Babel
 *
 * @package babel
 * @subpackage lexicon
 */
$_lang['babel.permission.babel_settings_desc'] = 'Zum Aktualisieren der TwoFactorX-Einstellungen auf der Babel-Manager-Seite.';
