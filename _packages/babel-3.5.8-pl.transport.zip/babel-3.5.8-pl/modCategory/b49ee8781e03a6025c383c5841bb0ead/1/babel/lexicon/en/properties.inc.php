<?php
/**
 * Properties Lexicon Entries for Babel
 *
 * @package babel
 * @subpackage lexicon
 */
$_lang['babel.babellinks.activeCls'] = 'CSS class for the active language link.';
$_lang['babel.babellinks.ignoreSiteStatus'] = 'Specifies whether the site_status is ignored (when the site is offline).';
$_lang['babel.babellinks.includeUnlinked'] = 'Specifies whether the unlinked contexts are shown.';
$_lang['babel.babellinks.outputSeparator'] = 'Separator between the language links.';
$_lang['babel.babellinks.resourceId'] = 'ID of resource of which links to translations should be displayed.';
$_lang['babel.babellinks.restrictToGroup'] = 'Restrict the contexts in the snippet output to the group the current context belongs to. See `babel.contextKeys` system setting for defining context key groups.';
$_lang['babel.babellinks.showCurrent'] = 'Specifies whether a link to the current language is shown.';
$_lang['babel.babellinks.showUnpublished'] = 'Specifies whether the unpublished translations are shown.';
$_lang['babel.babellinks.sortby'] = 'Context field to sort the results by. The default \'babel\' means to sort by the order of the context keys in the babel.contextKeys system setting.';
$_lang['babel.babellinks.sortdir'] = 'The direction to sort in.';
$_lang['babel.babellinks.toArray'] = 'Specifies whether the output is dumped as an array.';
$_lang['babel.babellinks.toPlaceholder'] = 'Specifies whether the output is dumped into the given placeholder\'s name.';
$_lang['babel.babellinks.tpl'] = 'Chunk to display a language link.';
$_lang['babel.babellinks.useRequestProperties'] = 'Specifies whether the current request properties are used in the links to the translated resources.';
$_lang['babel.babellinks.wrapperTpl'] = 'Chunk to wrap all language links. The placeholder for all links is [[+babelLinks]].';
$_lang['babel.babeltranslation.contextKey'] = 'Key of context in which translated resource should be determined.';
$_lang['babel.babeltranslation.cultureKey'] = 'Culture key for which to find the translated resource. Only used if contextKey is not specified. If both are omitted, the currently set cultureKey is used.';
$_lang['babel.babeltranslation.resourceId'] = 'Comma-separated list of resource IDs. The snippet returns the IDs of their translations for the contextKey or cultureKey.';
$_lang['babel.babeltranslation.showUnpublished'] = 'Specifies whether the unpublished translations are shown.';
$_lang['babel.babeltranslation.toPlaceholder'] = 'Specifies whether to dump the output into the given placeholder\'s name.';
